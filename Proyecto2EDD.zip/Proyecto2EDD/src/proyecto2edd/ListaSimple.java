package proyecto2edd;

public class ListaSimple {
    NodoListaCliente primero;
    NodoListaCliente ultimo;
    int numeroNodos = 0;
    
    //-----CONSTRUCTOR-----
    public ListaSimple(){
        primero = ultimo = null;
    }
    
    public boolean estaVacia(){
        return (primero == null) && (ultimo == null);
    }
    
    public void insertarInicio(Cliente dato){ //METODO PARA INSERTAR EN UNA PILA
        numeroNodos++;
        if (estaVacia()) 
            primero = ultimo = new NodoListaCliente(dato); //Se crea el nuevo nodo y se asigna a primero y a ultimo si la lista esta vacia
        else{
            NodoListaCliente nuevo = new NodoListaCliente(dato); //Se crea el nodo
            nuevo.setSiguiente(primero); //Se enlaza el nuevo nodo al primero (nuevo apunta a primero)
            primero = nuevo; //Se verifica que el nodo creado sea el primero
        }
    }
    
    public void insertarFinal(Cliente dato){ //METODO PARA INSERTAR EN UNA COLA
        numeroNodos++;
        if (estaVacia())
            primero = ultimo = new NodoListaCliente(dato); //Se crea el nuevo nodo y se asigna a primero y a ultimo si la lista esta vacia
        else{
            NodoListaCliente nuevo = new NodoListaCliente(dato); //Se crea el nodo
            ultimo.setSiguiente(nuevo); //Se enlaza el ultimo nodo al nuevo (ultimo apunta a nuevo)
            ultimo = nuevo; //Se verifica que el nodo creado sea el ultimo
        }
    }
    
    //METODO PARA CLIENTES
    public NodoListaCliente buscarNodo(String datoBuscar){
        NodoListaCliente temporal = primero; //Se crea un nodo temporal
        while(temporal != null){ //El ciclo se repetira hasta llegar al ultimo nodo
            if (datoBuscar == temporal.getCliente().getDpi()) {
                return temporal; //Si el dato fue encontrado, devuelve el nodo en el que estaba
            }
            temporal = temporal.getSiguiente(); //En cada iteracion el nodo temporal va tomando el valod del siguiente nodo
        }
        return null; //Si no encuentra el nodo donde esta el dato, devuelve null
    }
    
    public void insertarEntreNodos(String datoAnterior, String datoInsertar){
        NodoListaCliente nuevo, temporal; //Creando referencias
        temporal = buscarNodo(datoAnterior); //Realiza la busqueda del nodo anterior donde se insertara el nuevo dato
        if (temporal != null) {
            numeroNodos++;
            nuevo = new NodoListaCliente(datoInsertar); //Se crea el nuevo nodo a insertar
            nuevo.setSiguiente(temporal.getSiguiente()); //Se enlaza el nuevo nodo al siguiente del nodo anterior
            temporal.setSiguiente(nuevo); //El nodo anterior apunta al nuevo nodo
        }else //Si el nodo anterior no fue encontrado
            System.out.println("No se encontro el dato anterior");
            //JOptionPane.showMessageDialog(null, "No se encontro el dato anterior", "Error", JOptionPane.ERROR_MESSAGE);
    }    
    
    public void eliminarInicio(){ //METODO PARA ELIMINAR DE UNA PILA Y UNA COLA
        if (estaVacia())
            System.out.println("La vista esta vacia");
        else{
            numeroNodos--;
            NodoListaCliente segundo = primero.getSiguiente(); //Se crea una referencia y se le asigna el siguiente nodo del primero
            primero = segundo; //Se verifica que el segundo nodo sea el primero
        }
    }
    
    public void eliminarFinal(){
        if (estaVacia()) {
            System.out.println("La lista esta vacia");
        }else{
            numeroNodos--;
            NodoListaCliente temporal = primero;
            if (primero == ultimo) { //Si primero y ultimo son iguales quiere decir que solo hay un nodo en la lista
                primero = ultimo = null; //Se eliminan las referencias
            }
            while(temporal != null){
                if (temporal.getSiguiente() == ultimo) { //Si el siguiente de temporal es el ultimo, entonces temporal es el antepenultimo
                    temporal.setSiguiente(null); //Se mueve el enlace, quitando la referencia al nodo que queremos quitar
                    ultimo = temporal; //Se verifica que temporal sea el ultimo
                    break;
                }
                temporal = temporal.getSiguiente(); //Recorriendo la Lista
            }
        }
    }
    
    
    //METODO PARA CLIENTES
    public void eliminarNodo(String datoEliminar){
        NodoListaCliente nodoActual = primero, nodoAnterior = null;
        boolean encontrado = false;
        if (estaVacia())
            System.out.println("La vista esta vacia");
        else if (primero.getCliente().getDpi() == datoEliminar){
            eliminarInicio();
            numeroNodos--;
        }
        else if (ultimo.getCliente().getDpi() == datoEliminar){
            eliminarFinal();
            numeroNodos--;
        }
        else{
            while(!encontrado){
                if (nodoActual.getSiguiente().getCliente().getDpi() == datoEliminar){
                    numeroNodos--;
                    nodoAnterior = nodoActual;
                    nodoActual = nodoActual.getSiguiente();
                    nodoAnterior.setSiguiente(nodoActual.getSiguiente());
                    encontrado = true;
                }
                nodoActual = nodoActual.getSiguiente();
                if (nodoActual.getSiguiente() == null) {
                    System.out.println("No se encontro el dato a eliminar");
                    break;
                }
            }
        }
    }
    
    public void visualizarLista(){
        if (estaVacia()) {
            System.out.println("La lista esta vacia");
        }else{
            NodoListaCliente actual = primero;
            while(actual != null){
                System.out.println("Dato: " + actual.getCliente().getDpi());
                actual = actual.getSiguiente();
            }
        }
    }
    
    public void listaOrdenada(Cliente entrada){
        numeroNodos++;
        NodoListaCliente nuevo = new NodoListaCliente(entrada);
        if (estaVacia()) {
            primero = ultimo = nuevo;
        }else if(Long.parseLong(entrada.getDpi()) < Long.parseLong(primero.getCliente().getDpi())){
            nuevo.setSiguiente(primero);
            primero = nuevo;
        }else if(Long.parseLong(entrada.getDpi()) > Long.parseLong(ultimo.getCliente().getDpi())){
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }else{
            NodoListaCliente nodoAnterior, nodoActual;
            nodoAnterior = nodoActual = primero;
            while(Long.parseLong(entrada.getDpi()) > Long.parseLong(nodoActual.getCliente().getDpi())){
                nodoAnterior = nodoActual;
                nodoActual = nodoActual.getSiguiente();
            }
            nodoAnterior.setSiguiente(nuevo);
            nuevo.setSiguiente(nodoActual);
        }
    }
}
