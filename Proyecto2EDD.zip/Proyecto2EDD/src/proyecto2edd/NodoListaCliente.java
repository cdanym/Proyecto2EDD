package proyecto2edd;

public class NodoListaCliente {
    String dato;
    Cliente cliente;
    NodoListaCliente anterior;
    NodoListaCliente siguiente;
    
    public NodoListaCliente(String dato){
        this.dato = dato;
        siguiente = null;
        anterior = null;
    }
    
    public NodoListaCliente(Cliente cliente){
        this.cliente = cliente;
        siguiente = null;
        anterior = null;
    }
    
    public NodoListaCliente(String dato, NodoListaCliente siguiente){
        this.dato = dato;
        this.siguiente = siguiente;
    }
    
    protected String getDato(){
        return this.dato;
    }
    
    protected void setDato(String dato){
        this.dato = dato;
    }
    
    protected Cliente getCliente(){
        return this.cliente;
    }
    
    protected void setCliente(Cliente cliente){
        this.cliente = cliente;
    }
    
    protected NodoListaCliente getSiguiente(){
        return this.siguiente;
    }
    
    protected void setSiguiente(NodoListaCliente siguiente){
        this.siguiente = siguiente;
    }
    
    protected NodoListaCliente getAnterior(){
        return this.anterior;
    }
    
    protected void setAnteior(NodoListaCliente Anterior){
        this.anterior = anterior;
    }
}
