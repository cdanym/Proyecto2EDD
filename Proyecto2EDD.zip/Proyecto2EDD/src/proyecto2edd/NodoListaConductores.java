package proyecto2edd;

public class NodoListaConductores {
    String dato;
    Conductor conductor;
    NodoListaConductores anterior;
    NodoListaConductores siguiente;
    
    public NodoListaConductores(String dato){
        this.dato = dato;
        siguiente = null;
        anterior = null;
    }
    
    public NodoListaConductores(Conductor conductor){
        this.conductor = conductor;
        siguiente = null;
        anterior = null;
    }
    
    public NodoListaConductores(String dato, NodoListaConductores siguiente){
        this.dato = dato;
        this.siguiente = siguiente;
    }
    
    protected String getDato(){
        return this.dato;
    }
    
    protected void setDato(String dato){
        this.dato = dato;
    }
    
    protected Conductor getConductor(){
        return this.conductor;
    }
    
    protected void setConductor(Conductor conductor){
        this.conductor = conductor;
    }
    
    protected NodoListaConductores getSiguiente(){
        return this.siguiente;
    }
    
    protected void setSiguiente(NodoListaConductores siguiente){
        this.siguiente = siguiente;
    }
    
    protected NodoListaConductores getAnterior(){
        return this.anterior;
    }
    
    protected void setAnteior(NodoListaConductores Anterior){
        this.anterior = anterior;
    }
}
