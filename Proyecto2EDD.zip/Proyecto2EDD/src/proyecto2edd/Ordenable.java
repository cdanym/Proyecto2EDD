package proyecto2edd;

public class Ordenable {
    public Ordenable() {

    }

    public boolean igualA(Ordenable o) {
        return false;
    }

    public boolean menorQue(Ordenable o) {
        return false;
    }

    public boolean mayorQue(Ordenable o) {
        return false;
    }

    public boolean menorOIgualQue(Ordenable o) {
        return false;
    }

    public boolean mayorOIgualQue(Ordenable o) {
        return false;
    }

    public Ordenable minKey() {
        return null;
    }

    public Object getKey() {
        return null;
    }
}
