
package proyecto2edd;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author daniel
 */
public class Principal extends javax.swing.JFrame {
    
    public File archivoEntrada, archivoGuardar;
    public JFileChooser fileChooser;
    public String textoEntrada, rutaGuardar;
        
    Grafo miGrafo;  //GRAFO - RUTAS
    ListaCircularDoble miListaCD; //LISTA CIRCULAR DOBLE - CONDUCTORES
    static ArbolB miArbolB;  //ARBOL B - VEHICULOS
    TablaHash miTabla; //TABLA HASH - CLIENTES
    
    public Principal() {
        initComponents();
        
        this.setLocationRelativeTo(null);
        this.setTitle("Proyecto 2");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setVisible(true);       
        
    }
    
    
    static void graficarArbol(){
        
        String ruta = "graficaAB.dot";
        File archivoGrafica = new File(ruta);
        BufferedWriter bw;
        try {
            bw = new BufferedWriter(new FileWriter(archivoGrafica));
            bw.write(miArbolB.toDot());
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            String cmd1 = "dot -Tpng graficaAB.dot -o graficaAB.png"; //Comando
            Runtime.getRuntime().exec(cmd1);
        } catch (IOException ioe) {
                System.out.println (ioe);
        }
        
        try {
            Desktop desk;
            desk = Desktop.getDesktop();
            //desk.open(archivoGrafica);
            desk.open(new File("graficaAB.png"));
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtArea = new javax.swing.JTextArea();
        btAbrir = new javax.swing.JButton();
        btClientes = new javax.swing.JButton();
        btVehiculos = new javax.swing.JButton();
        btConductores = new javax.swing.JButton();
        btViajes = new javax.swing.JButton();
        btRutas = new javax.swing.JButton();
        btSalir = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        menuArchivo = new javax.swing.JMenu();
        itemAbrir = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        itemSalir = new javax.swing.JMenuItem();
        menuMenu = new javax.swing.JMenu();
        menuClientes = new javax.swing.JMenu();
        iClienteAgregar = new javax.swing.JMenuItem();
        iClienteModificar = new javax.swing.JMenuItem();
        iClienteEliminar = new javax.swing.JMenuItem();
        iClienteInfo = new javax.swing.JMenuItem();
        iClienteEstructura = new javax.swing.JMenuItem();
        menuVehiculos = new javax.swing.JMenu();
        iVehicuAgregar = new javax.swing.JMenuItem();
        iVehiModificar = new javax.swing.JMenuItem();
        iVehiEliminar = new javax.swing.JMenuItem();
        iVehiInfo = new javax.swing.JMenuItem();
        iVehiEstructura = new javax.swing.JMenuItem();
        menuConductores = new javax.swing.JMenu();
        iConducAgregar = new javax.swing.JMenuItem();
        iConducModificar = new javax.swing.JMenuItem();
        iConducEliminar = new javax.swing.JMenuItem();
        iConducInfo = new javax.swing.JMenuItem();
        iConducEstructura = new javax.swing.JMenuItem();
        menuViajes = new javax.swing.JMenu();
        iViajeAgregar = new javax.swing.JMenuItem();
        iViajeModificar = new javax.swing.JMenuItem();
        iViajeEliminar = new javax.swing.JMenuItem();
        iViajeInfo = new javax.swing.JMenuItem();
        iViajeEstructura = new javax.swing.JMenuItem();
        menuRutas = new javax.swing.JMenu();
        iRutaAgregar = new javax.swing.JMenuItem();
        iRutaEstructura = new javax.swing.JMenuItem();
        menuTop = new javax.swing.JMenu();
        topClientes = new javax.swing.JMenuItem();
        topVehiculos = new javax.swing.JMenuItem();
        topConductores = new javax.swing.JMenuItem();
        topViajes = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtArea.setColumns(20);
        txtArea.setRows(5);
        jScrollPane1.setViewportView(txtArea);

        btAbrir.setText("Abrir Archivo");
        btAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAbrirActionPerformed(evt);
            }
        });

        btClientes.setText("Clientes");
        btClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btClientesActionPerformed(evt);
            }
        });

        btVehiculos.setText("Vehiculos");
        btVehiculos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btVehiculosActionPerformed(evt);
            }
        });

        btConductores.setText("Conductores");
        btConductores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btConductoresActionPerformed(evt);
            }
        });

        btViajes.setText("Viajes");
        btViajes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btViajesActionPerformed(evt);
            }
        });

        btRutas.setText("Rutas");
        btRutas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btRutasActionPerformed(evt);
            }
        });

        btSalir.setText("Salir");
        btSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 440, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(btViajes, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(55, 55, 55)
                                .addComponent(btRutas, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(btVehiculos, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(136, 136, 136)
                        .addComponent(btSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(btConductores, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(btAbrir, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(btAbrir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btClientes)
                    .addComponent(btVehiculos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btConductores)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btRutas)
                    .addComponent(btViajes))
                .addGap(18, 18, 18)
                .addComponent(btSalir)
                .addContainerGap(130, Short.MAX_VALUE))
        );

        menuArchivo.setText("Archivo");

        itemAbrir.setText("Abrir archivo");
        itemAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemAbrirActionPerformed(evt);
            }
        });
        menuArchivo.add(itemAbrir);
        menuArchivo.add(jSeparator1);

        itemSalir.setText("Salir");
        menuArchivo.add(itemSalir);

        menuBar.add(menuArchivo);

        menuMenu.setText("Menu");

        menuClientes.setText("Clientes");

        iClienteAgregar.setText("Agregar");
        iClienteAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iClienteAgregarActionPerformed(evt);
            }
        });
        menuClientes.add(iClienteAgregar);

        iClienteModificar.setText("Modificar");
        menuClientes.add(iClienteModificar);

        iClienteEliminar.setText("Eliminar");
        iClienteEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iClienteEliminarActionPerformed(evt);
            }
        });
        menuClientes.add(iClienteEliminar);

        iClienteInfo.setText("Informacion");
        iClienteInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iClienteInfoActionPerformed(evt);
            }
        });
        menuClientes.add(iClienteInfo);

        iClienteEstructura.setText("Estructura");
        iClienteEstructura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iClienteEstructuraActionPerformed(evt);
            }
        });
        menuClientes.add(iClienteEstructura);

        menuMenu.add(menuClientes);

        menuVehiculos.setText("Vehiculos");

        iVehicuAgregar.setText("Agregar");
        iVehicuAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iVehicuAgregarActionPerformed(evt);
            }
        });
        menuVehiculos.add(iVehicuAgregar);

        iVehiModificar.setText("Modificar");
        menuVehiculos.add(iVehiModificar);

        iVehiEliminar.setText("Eliminar");
        iVehiEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iVehiEliminarActionPerformed(evt);
            }
        });
        menuVehiculos.add(iVehiEliminar);

        iVehiInfo.setText("Informacion");
        iVehiInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iVehiInfoActionPerformed(evt);
            }
        });
        menuVehiculos.add(iVehiInfo);

        iVehiEstructura.setText("Estructura");
        iVehiEstructura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iVehiEstructuraActionPerformed(evt);
            }
        });
        menuVehiculos.add(iVehiEstructura);

        menuMenu.add(menuVehiculos);

        menuConductores.setText("Conductores");

        iConducAgregar.setText("Agregar");
        iConducAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iConducAgregarActionPerformed(evt);
            }
        });
        menuConductores.add(iConducAgregar);

        iConducModificar.setText("Modificar");
        menuConductores.add(iConducModificar);

        iConducEliminar.setText("Eliminar");
        iConducEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iConducEliminarActionPerformed(evt);
            }
        });
        menuConductores.add(iConducEliminar);

        iConducInfo.setText("Informacion");
        iConducInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iConducInfoActionPerformed(evt);
            }
        });
        menuConductores.add(iConducInfo);

        iConducEstructura.setText("Estructura");
        iConducEstructura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iConducEstructuraActionPerformed(evt);
            }
        });
        menuConductores.add(iConducEstructura);

        menuMenu.add(menuConductores);

        menuViajes.setText("Viajes");

        iViajeAgregar.setText("Agregar");
        menuViajes.add(iViajeAgregar);

        iViajeModificar.setText("Modificar");
        menuViajes.add(iViajeModificar);

        iViajeEliminar.setText("Eliminar");
        menuViajes.add(iViajeEliminar);

        iViajeInfo.setText("Informacion");
        menuViajes.add(iViajeInfo);

        iViajeEstructura.setText("Estructura");
        menuViajes.add(iViajeEstructura);

        menuMenu.add(menuViajes);

        menuRutas.setText("Rutas");

        iRutaAgregar.setText("Agregar");
        menuRutas.add(iRutaAgregar);

        iRutaEstructura.setText("Estructura");
        menuRutas.add(iRutaEstructura);

        menuMenu.add(menuRutas);

        menuBar.add(menuMenu);

        menuTop.setText("Top");

        topClientes.setText("Clientes");
        menuTop.add(topClientes);

        topVehiculos.setText("Vehiculos");
        menuTop.add(topVehiculos);

        topConductores.setText("Conductores");
        menuTop.add(topConductores);

        topViajes.setText("Viajes");
        menuTop.add(topViajes);

        menuBar.add(menuTop);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(40, 40, 40))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(43, 43, 43))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAbrirActionPerformed
        // TODO add your handling code here:
        fileChooser = new JFileChooser("C:\\Users\\Daniel\\Desktop\\");            
//        FiltroText filtro = new FiltroText();
//        fileChooser.setFileFilter(filtro);
        int respuestaFileChooser = fileChooser.showOpenDialog(null);
        if (respuestaFileChooser == JFileChooser.APPROVE_OPTION) {
            txtArea.setText(null);
            leer();
            this.setTitle("Proyecto 2 - " + archivoEntrada.getName());
        }
    }//GEN-LAST:event_btAbrirActionPerformed

    private void btClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btClientesActionPerformed
        // TODO add your handling code here:
        //SE ANALIZARA EL ARCHIVO DE ENTRADA QUE CONTIENE LOS CLIENTES
        String cadena = textoEntrada;
        String[] clientes = cadena.split(";");
        
        System.out.println("Tamaño clientes: " + clientes.length); //Cantidad de clientes
        for (int i = 0; i < (clientes.length-1); i++) {
            System.out.println("Split: " + i + clientes[i].trim());
        }
        
        miTabla = new TablaHash(); //TABLA HASH - CLIENTES
        
        for (int i = 0; i < (clientes.length-1); i++) {
            String[] cliente = clientes[i].trim().split(",");
            Cliente temporal = new Cliente(cliente[0], cliente[1], cliente[2], cliente[3], cliente[4], cliente[5]);
            miTabla.insertar(temporal);
        }
        
        /*Cliente cliente1 = new Cliente("12345", "nombre1", "apellido1", "genero1", "telefono1", "direccion1");
        Cliente cliente2 = new Cliente("12419", "nombre1", "apellido1", "genero1", "telefono1", "direccion1");
        Cliente cliente3 = new Cliente("22419", "nombre1", "apellido1", "genero1", "telefono1", "direccion1");
        miTabla.insertar(cliente1);
        miTabla.insertar(cliente2);
        miTabla.insertar(cliente3);*/
        miTabla.visualizarTabla(); 
        
    }//GEN-LAST:event_btClientesActionPerformed

    private void btVehiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btVehiculosActionPerformed
        // TODO add your handling code here:
        //SE ANALIZARA EL ARCHIVO DE ENTRADA QUE CONTIENE LOS VEHICULOS
        String cadena = textoEntrada;
        String[] vehiculos = cadena.split(";");
        
        System.out.println("Tamaño vehiculos: " + vehiculos.length); //Cantidad de conductores
        for (int i = 0; i < (vehiculos.length-1); i++) {
            System.out.println("Split: " + i + vehiculos[i].trim());
        }
        miArbolB = new ArbolB(); //ARBOL B - VEHICULOS
        for (int i = 0; i < (vehiculos.length-1); i++) {
            String[] vehiculo = vehiculos[i].trim().split(":");
            miArbolB.insert(new LlaveEntero(vehiculo[0]), "Dummy " + i);
            
        }
        /*String[] values = { "100A", "101B", "40C", "30D", "25E", "26F", "15G", "99H", "205I", "360J", "80K", "200L" };
        for (int i = 0; i < values.length; i++) {
            miArbolB.insert(new LlaveEntero(values[i]), "Dummy " + i);
        }*/
        graficarArbol(); 
    }//GEN-LAST:event_btVehiculosActionPerformed

    private void btConductoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btConductoresActionPerformed
        // TODO add your handling code here:
        //SE ANALIZARA EL ARCHIVO DE ENTRADA QUE CONTIENE LOS CONDUCTORES
        String cadena = textoEntrada;
        String[] conductores = cadena.split(";");
        
        System.out.println("Tamaño conductores: " + conductores.length); //Cantidad de conductores
        for (int i = 0; i < (conductores.length-1); i++) {
            System.out.println("Split: " + i + conductores[i].trim());
        }
        
        miListaCD = new ListaCircularDoble(); //LISTA CIRCULAR DOBLE - CONDUCTORES
        
        for (int i = 0; i < (conductores.length-1); i++) {
            String[] conductor = conductores[i].trim().split("%");
            Conductor temporal = new Conductor(conductor[0], conductor[1], conductor[2], conductor[3], conductor[4], conductor[5],conductor[6],conductor[7]);
            miListaCD.insertarFinal(temporal);
        }
        
        miListaCD.visualizarLista();
    }//GEN-LAST:event_btConductoresActionPerformed

    private void btViajesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btViajesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btViajesActionPerformed

    private void btRutasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRutasActionPerformed
        // TODO add your handling code here:
        
        //SE ANALIZARA EL ARCHIVO DE ENTRADA QUE CONTIENE LAS RUTAS
        String cadena = textoEntrada;
        String[] rutas = cadena.split("%");
        System.out.println("Tamaño rutas: " + rutas.length); //16, pero en realidad son 15. Toma el salto de linea de abajo
        for (int i = 0; i < (rutas.length-1); i++) {
            System.out.println("Split: " + i + rutas[i].trim());
        }
     
        ArrayList<String> listaCiudades = new ArrayList<>();
        
        for (int i = 0; i < (rutas.length-1); i++) {
            String[] ciudades = rutas[i].trim().split("/");
            for (int j = 0; j < 2; j++) {
                if (i == 0) {
                    listaCiudades.add(ciudades[j]);
                }
                else{
                    if (!listaCiudades.contains(ciudades[j])) {
                        listaCiudades.add(ciudades[j]);
                    }
                }
            }
        }
        
        miGrafo = new Grafo(listaCiudades.size()); //GRAFO - RUTAS
        System.out.println("Tamaño ciudades: " + listaCiudades.size());
        for (int i = 0; i < listaCiudades.size(); i++) {
            System.out.println(listaCiudades.get(i));
            miGrafo.nuevoVertice(listaCiudades.get(i));
        }
        
        for (int i = 0; i < (rutas.length-1); i++) {
            String[] ciudades = rutas[i].trim().split("/");
            try {
                miGrafo.nuevoArco(ciudades[0], ciudades[1] ,Integer.parseInt(ciudades[2]));
            } catch (Exception ex) {
                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        miGrafo.imprimirMatriz();
    }//GEN-LAST:event_btRutasActionPerformed

    private void btSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalirActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btSalirActionPerformed

    private void itemAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemAbrirActionPerformed
        // TODO add your handling code here:
        fileChooser = new JFileChooser("C:\\Users\\Daniel\\Desktop\\");            
//        FiltroText filtro = new FiltroText();
//        fileChooser.setFileFilter(filtro);
        int respuestaFileChooser = fileChooser.showOpenDialog(null);
        if (respuestaFileChooser == JFileChooser.APPROVE_OPTION) {
            txtArea.setText(null);
            leer();
            this.setTitle("Proyecto 2 - " + archivoEntrada.getName());
        }
    }//GEN-LAST:event_itemAbrirActionPerformed

    private void iClienteAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iClienteAgregarActionPerformed
        // TODO add your handling code here:
        String dpi,nombre,apellido,genero,telefono,direccion;
        dpi = JOptionPane.showInputDialog("Ingrese dpi");
        nombre = JOptionPane.showInputDialog("Ingrese nombre");
        apellido = JOptionPane.showInputDialog("Ingrese apellido");
        genero = JOptionPane.showInputDialog("Ingrese genero");
        telefono = JOptionPane.showInputDialog("Ingrese telefono");
        direccion = JOptionPane.showInputDialog("Ingrese direccion");
        Cliente nuevoCliente = new Cliente(dpi, nombre, apellido, genero, telefono, direccion);
        miTabla.insertar(nuevoCliente);
    }//GEN-LAST:event_iClienteAgregarActionPerformed

    private void iClienteEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iClienteEliminarActionPerformed
        // TODO add your handling code here:
        String dpi;
        dpi = JOptionPane.showInputDialog("Ingrese dpi");
        miTabla.eliminar(dpi);
    }//GEN-LAST:event_iClienteEliminarActionPerformed

    private void iClienteEstructuraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iClienteEstructuraActionPerformed
        // TODO add your handling code here:
        miTabla.visualizarTabla();
    }//GEN-LAST:event_iClienteEstructuraActionPerformed

    private void iClienteInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iClienteInfoActionPerformed
        // TODO add your handling code here:
        String dpi;
        dpi = JOptionPane.showInputDialog("Ingrese dpi");
        Cliente temporal = miTabla.buscar(dpi);
        System.out.println("DPI: " + temporal.getDpi());
        System.out.println("Nombre: " + temporal.getNombre());
        System.out.println("Apellido: " + temporal.getApellido());
        System.out.println("Genero: " + temporal.getGenero());
        System.out.println("Telefono: " + temporal.getTelefono());
        System.out.println("Direccion: " + temporal.getDireccion());
    }//GEN-LAST:event_iClienteInfoActionPerformed

    private void iVehicuAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iVehicuAgregarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iVehicuAgregarActionPerformed

    private void iVehiEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iVehiEliminarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iVehiEliminarActionPerformed

    private void iVehiInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iVehiInfoActionPerformed
        // TODO add your handling code here:
        graficarArbol(); 
    }//GEN-LAST:event_iVehiInfoActionPerformed

    private void iVehiEstructuraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iVehiEstructuraActionPerformed
        // TODO add your handling code here:
        graficarArbol(); 
    }//GEN-LAST:event_iVehiEstructuraActionPerformed

    private void iConducAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iConducAgregarActionPerformed
        // TODO add your handling code here:
        String dpi,nombre,apellido,licencia,genero,fechaNac,telefono,direccion;
        dpi = JOptionPane.showInputDialog("Ingrese dpi");
        nombre = JOptionPane.showInputDialog("Ingrese nombre");
        apellido = JOptionPane.showInputDialog("Ingrese apellido");
        licencia = JOptionPane.showInputDialog("Ingrese licencia");
        genero = JOptionPane.showInputDialog("Ingrese genero");
        fechaNac = JOptionPane.showInputDialog("Ingrese fecha de nacimiento");
        telefono = JOptionPane.showInputDialog("Ingrese telefono");
        direccion = JOptionPane.showInputDialog("Ingrese direccion");
        Conductor nuevoConductor = new Conductor(dpi, nombre, apellido, licencia, genero, fechaNac, telefono, direccion);
        miListaCD.insertarFinal(nuevoConductor);
    }//GEN-LAST:event_iConducAgregarActionPerformed

    private void iConducEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iConducEliminarActionPerformed
        // TODO add your handling code here:
        String dpi;
        dpi = JOptionPane.showInputDialog("Ingrese dpi");
        miListaCD.eliminarNodo(dpi);
    }//GEN-LAST:event_iConducEliminarActionPerformed

    private void iConducInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iConducInfoActionPerformed
        // TODO add your handling code here:
        String dpi;
        dpi = JOptionPane.showInputDialog("Ingrese dpi");
        NodoListaConductores temporal = miListaCD.buscarNodo(dpi);
        System.out.println("DPI: " + temporal.getConductor().getDpi());
        System.out.println("Nombre: " + temporal.getConductor().getNombre());
        System.out.println("Apellido: " + temporal.getConductor().getApellido());
        System.out.println("Licencia: " + temporal.getConductor().getLicencia());
        System.out.println("Genero: " + temporal.getConductor().getGenero());
        System.out.println("Telefono: " + temporal.getConductor().getTelefono());
        System.out.println("Direccion: " + temporal.getConductor().getDireccion());
    }//GEN-LAST:event_iConducInfoActionPerformed

    private void iConducEstructuraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iConducEstructuraActionPerformed
        // TODO add your handling code here:
        miListaCD.visualizarLista();
    }//GEN-LAST:event_iConducEstructuraActionPerformed

    protected void leer(){
        archivoEntrada = fileChooser.getSelectedFile();
        textoEntrada = "";
        String linea="";
        try{
            FileReader fr = new FileReader(archivoEntrada);
            BufferedReader br = new BufferedReader(fr);
            while(linea != null){
                linea = br.readLine();
                if (linea == null) {
                    break;
                }
                textoEntrada += linea+"\n";
            }
            br.close();
            txtArea.setText(textoEntrada);
        }catch(Exception ex){
            
        }
        rutaGuardar = archivoEntrada.getPath();
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAbrir;
    private javax.swing.JButton btClientes;
    private javax.swing.JButton btConductores;
    private javax.swing.JButton btRutas;
    private javax.swing.JButton btSalir;
    private javax.swing.JButton btVehiculos;
    private javax.swing.JButton btViajes;
    private javax.swing.JMenuItem iClienteAgregar;
    private javax.swing.JMenuItem iClienteEliminar;
    private javax.swing.JMenuItem iClienteEstructura;
    private javax.swing.JMenuItem iClienteInfo;
    private javax.swing.JMenuItem iClienteModificar;
    private javax.swing.JMenuItem iConducAgregar;
    private javax.swing.JMenuItem iConducEliminar;
    private javax.swing.JMenuItem iConducEstructura;
    private javax.swing.JMenuItem iConducInfo;
    private javax.swing.JMenuItem iConducModificar;
    private javax.swing.JMenuItem iRutaAgregar;
    private javax.swing.JMenuItem iRutaEstructura;
    private javax.swing.JMenuItem iVehiEliminar;
    private javax.swing.JMenuItem iVehiEstructura;
    private javax.swing.JMenuItem iVehiInfo;
    private javax.swing.JMenuItem iVehiModificar;
    private javax.swing.JMenuItem iVehicuAgregar;
    private javax.swing.JMenuItem iViajeAgregar;
    private javax.swing.JMenuItem iViajeEliminar;
    private javax.swing.JMenuItem iViajeEstructura;
    private javax.swing.JMenuItem iViajeInfo;
    private javax.swing.JMenuItem iViajeModificar;
    private javax.swing.JMenuItem itemAbrir;
    private javax.swing.JMenuItem itemSalir;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JMenu menuArchivo;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menuClientes;
    private javax.swing.JMenu menuConductores;
    private javax.swing.JMenu menuMenu;
    private javax.swing.JMenu menuRutas;
    private javax.swing.JMenu menuTop;
    private javax.swing.JMenu menuVehiculos;
    private javax.swing.JMenu menuViajes;
    private javax.swing.JMenuItem topClientes;
    private javax.swing.JMenuItem topConductores;
    private javax.swing.JMenuItem topVehiculos;
    private javax.swing.JMenuItem topViajes;
    private javax.swing.JTextArea txtArea;
    // End of variables declaration//GEN-END:variables
}
