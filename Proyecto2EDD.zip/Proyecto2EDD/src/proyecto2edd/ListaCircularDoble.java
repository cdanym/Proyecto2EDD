package proyecto2edd;

import java.awt.Desktop;

import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ListaCircularDoble {
    NodoListaConductores primero,ultimo;
    File archivoGrafica, grafica;
    String ruta;
    String strGrafica;
    
    public ListaCircularDoble(){
        primero = ultimo = null;
    }
    
    public boolean estaVacia(){
        return (primero==null) && (ultimo == null);
    }
    
    public void insertarInicio(Conductor dato){
        if (estaVacia()) {
            NodoListaConductores nuevo = new NodoListaConductores(dato);
            nuevo.setAnteior(nuevo);
            nuevo.setSiguiente(nuevo);
            primero = ultimo = nuevo;
        }else{
            NodoListaConductores nuevo = new NodoListaConductores(dato);
            nuevo.setSiguiente(primero);
            primero.setAnteior(nuevo);
            nuevo.setAnteior(ultimo);
            ultimo.setSiguiente(nuevo);
            primero = nuevo;
        }
    }
    
    public void insertarFinal(Conductor dato){
        if (estaVacia()) {
            NodoListaConductores nuevo = new NodoListaConductores(dato);
            nuevo.setAnteior(nuevo);
            nuevo.setSiguiente(nuevo);
            ultimo = primero = nuevo;
        }else{
            NodoListaConductores nuevo = new NodoListaConductores(dato);
            nuevo.setSiguiente(primero);
            nuevo.setAnteior(ultimo);
            primero.setAnteior(nuevo);
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }
    }
    
    public void eliminarInicio(){
        if (estaVacia()) {
            System.out.println("La lista esta vacia");
        }else{
            NodoListaConductores segundo = primero.getSiguiente();
            ultimo.setSiguiente(segundo);
            segundo.setAnteior(ultimo);
            primero = segundo;
        }
    }
    
    public void eliminarFinal(){
        if (estaVacia()) {
            System.out.println("La lista esta vacia");
        }else{
            NodoListaConductores antepenultimo = ultimo;
            antepenultimo.setSiguiente(primero);
            primero.setAnteior(antepenultimo);
            ultimo = antepenultimo;
        }
    }
    
    public NodoListaConductores buscarNodo(Object datoBuscar){
        NodoListaConductores temporal = primero;
        if (estaVacia()) {
            System.out.println("La lista esta vacia");
            return null;
        }else{
            do {
                if (temporal.getDato()==datoBuscar) {
                    return temporal;
                }
                temporal = temporal.getSiguiente();
            } while (temporal != primero);
            //System.out.println("No se encontro el elemento buscado");
            return null;
        }
    }
    
    public void insertarEntreNodos(String datoAnterior, String datoInsertar){
        NodoListaConductores nuevo, temporalAnterior;
        nuevo = new NodoListaConductores(datoInsertar);
        temporalAnterior = buscarNodo(datoAnterior);
        if (temporalAnterior != null) {
            nuevo.setSiguiente(temporalAnterior.getSiguiente());
            nuevo.setAnteior(temporalAnterior);
            temporalAnterior.getSiguiente().setAnteior(nuevo);
            temporalAnterior.setSiguiente(nuevo);
        }else{
            System.out.println("No se encontro el dato anterior");
        }
    }
    
    public void eliminarNodo(Object datoEliminar){
        NodoListaConductores nodoActual = primero, nodoAnterior = null;
        boolean encontrado = false;
        if (estaVacia()) {
            System.out.println("La lista esta vacia");
        }else if(primero.getDato() == datoEliminar){
            eliminarInicio();
        }else if(ultimo.getDato() == datoEliminar){
            eliminarFinal();
        }else{
            while(!encontrado){
                if (nodoActual.getSiguiente().getDato() == datoEliminar) {
                    nodoAnterior = nodoActual;
                    nodoActual = nodoActual.getSiguiente();
                    nodoAnterior.setSiguiente(nodoActual.getSiguiente());
                    nodoActual.getSiguiente().setAnteior(nodoAnterior);
                    encontrado = true;
                }
                nodoActual = nodoActual.getSiguiente();
                if (nodoActual == primero) {
                    System.out.println("No se encontro el dato a eliminar");
                    break;
                }
            }
        }
    }
    
    public void visualizarLista(){
        if (estaVacia()) {
            System.out.println("La lista esta vacia");
        }else{
            NodoListaConductores actual = primero;
            do {
                System.out.println("Dato: " + actual.getDato());
                actual = actual.getSiguiente();
            } while (actual != primero);
        }
        
        crearGrafica();
        iniciarGrafica();
    }
    
    protected void crearGrafica(){
        strGrafica = "digraph g { rankdir = LR; ";
        String nodo = "";
        NodoListaConductores temporal = primero;
        do {
            nodo = temporal.getConductor().getDpi();
            strGrafica += nodo;
            strGrafica += " -> ";
            temporal = temporal.getSiguiente();
            strGrafica += temporal.getConductor().getDpi();
            strGrafica += ";";
            strGrafica += temporal.getConductor().getDpi();
            strGrafica += " -> ";
            strGrafica += nodo;
            strGrafica += ";";
        } while (temporal != primero);
        
        strGrafica += "}";
        //ruta="C:\\Users\\Daniel\\Desktop\\TablaTokens.html";
        ruta = "graficaLCD.dot";
        archivoGrafica = new File(ruta);
        BufferedWriter bw;
        try {
            bw = new BufferedWriter(new FileWriter(archivoGrafica));
            bw.write(strGrafica);
            bw.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            String cmd1 = "dot -Tpng graficaLCD.dot -o graficaLCD.png"; //Comando de apagado en linux
            Runtime.getRuntime().exec(cmd1);
            //String cmd2 = "display graficaLCD.png &";
            //Runtime.getRuntime().exec(cmd2);
        } catch (IOException ioe) {
                System.out.println (ioe);
        }
    }
    
    protected void iniciarGrafica(){
        try {
            Desktop desk;
            desk = Desktop.getDesktop();
            //desk.open(archivoGrafica);
            desk.open(new File("graficaLCD.png"));
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
