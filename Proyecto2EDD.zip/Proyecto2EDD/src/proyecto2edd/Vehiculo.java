package proyecto2edd;

public class Vehiculo {
    public String placa;
    public String marca;
    public String modelo;
    public String anio;
    public String color;
    public String precio;
    public String transmision;
    
    public Vehiculo(String placa, String marca, String modelo, String anio, String color, String precio, String transmision){
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
        this.color = color;
        this.precio = precio;
        this.transmision = transmision;
    }
}
