package proyecto2edd;

public class Split {
    NodoArbol mPuntero;
    Ordenable mLlave;
    Object mDato;

    public Split(NodoArbol pPuntero, Ordenable pLlave, Object pDato) {
        this.mPuntero = pPuntero;
        this.mLlave = pLlave;
        this.mDato = pDato;
    }

    public void setPuntero(NodoArbol mPuntero) {
        this.mPuntero = mPuntero;
    }

    public NodoArbol getPuntero() {
        return mPuntero;
    }

    public void setLlave(Ordenable mLlave) {
        this.mLlave = mLlave;
    }

    public Ordenable getLlave() {
        return mLlave;
    }

    public void setDato(Object mDato) {
        this.mDato = mDato;
    }

    public Object getDato() {
        return mDato;
    }
}
