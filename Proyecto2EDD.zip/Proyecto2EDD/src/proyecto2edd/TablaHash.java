package proyecto2edd;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TablaHash {
    static final int tamTabla = 37;
    private int numElementos;
    private double factorCarga;
    //private Cliente[] tabla; 
    protected ListaSimple[] tabla;
    File archivoGrafica, grafica;
    String ruta;
    String strGrafica; 
    
    public TablaHash(){
        tabla = new ListaSimple[tamTabla];
        for (int i = 0; i < tamTabla; i++) {
            tabla[i] = null;
            numElementos = 0;
            factorCarga = 0.0;
        }
        numElementos = 0;
        factorCarga = 0.0;
        //ListaSimple lista0 = new ListaSimple();
    }
    
    public int direccion(String clave){
        int i = 0, p;
        long d;
        d = transformaCadena(clave);
        //Aplica aritmetica modular para obtner direccion base
        p = (int)(d % tamTabla);
        //Bucle de exploracion
        /*while(tabla[p] != null && !tabla[p].buscarNodo(clave).getCliente().getDpi().equals(clave)){
            i++;
            p = p + i*i;
            p = p % tamTabla;
        }*/
        System.out.println("Modulo: " + Integer.toString(p));
        return p;
    }
    
    public long transformaCadena(String c){
        long d;
        d = Long.parseLong(c);
        return d;
    }
    
    public void insertar(Cliente cliente){
        int posicion;
        System.out.println("Tam arreglo: " + tabla.length);
        posicion = direccion(cliente.getDpi());
        if (tabla[posicion] == null) {
            tabla[posicion] = new ListaSimple();
            tabla[posicion].listaOrdenada(cliente);
        }
        else{
            tabla[posicion].listaOrdenada(cliente);
        }
        //cliente1.listaOrdenada(cliente);
        //tabla[posicion] = cliente;
        numElementos ++;
        factorCarga = (double)(numElementos/tamTabla);
        if (factorCarga > 0.75) {
            System.out.println("Factor de carga supera el 75%");
        }
    }
    
    public Cliente buscar(String clave){ //CLAVE = DPI
        Cliente temporal;
        int posicion;
        posicion = direccion(clave);
        temporal = tabla[posicion].buscarNodo(clave).getCliente();
        if (temporal != null) {
            //POR SI SE HA ELIMINADO ANTES ESE VALOR, DEVUELVE NULL
        }
        return temporal;
    }
    
    public void eliminar(String clave){
        int posicion;
        posicion = direccion(clave);
        tabla[posicion].eliminarNodo(clave);
    }
    
    public void visualizarTabla(){
        System.out.println("Numero de elementos: " + numElementos);
        
        crearGrafica();
        iniciarGrafica();
        
    }
    
    public void crearGrafica(){
        strGrafica = "digraph G { \n";
        strGrafica += "node[shape=box]\n";
        //CREANDO LOS INDICES
        for (int i = 0; i < tamTabla; i++) {
            strGrafica += ("F"+i + "[label= \""+i + "\", width=1.5, style=filled, group=2];" + "\n" );
        }
        //IMPRIMIR LOS INDICES Y ENLAZARLOS ENTRE ELLOS
        for (int i = 0; i < (tamTabla-1); i++) {
            strGrafica += ("F"+i + " -> " + "F"+(i+1) + "; \n");
        }
        
        for (int i = 0; i < (tamTabla-1); i++) {
            if (tabla[i] != null) {
                NodoListaCliente temporal = tabla[i].primero;
                if (temporal != null) {
                    for (int j = 0; j < tabla[i].numeroNodos; j++) {
                        strGrafica += ((Integer.toString(i)) + (Integer.toString(j)) + "[label= \"" + temporal.getCliente().getDpi()
                                + "\", width=1.5]; \n");
                        temporal = temporal.getSiguiente();
                        System.out.println("i:"+i + " j:"+j);
                    }
                }
                else{
                    System.out.println("No hay nodos en el indice " + i);
                }
            }
        }
        
        for (int i = 0; i < (tamTabla-1); i++) {
            if (tabla[i] != null) {
                for (int j = 0; j < tabla[i].numeroNodos; j++) {
                    if (j == 0) {
                        strGrafica += (("F"+i) + " -> " + (Integer.toString(i)) + (Integer.toString(j)) + "; \n");
                    }
                    else{
                        strGrafica += ( (Integer.toString(i))+(Integer.toString(j-1)) + " -> " + (Integer.toString(i))+(Integer.toString(j))
                                + "; \n");
                    }
                }
                strGrafica += "{rank = same; ";
                for (int j = 0; j <= tabla[i].numeroNodos; j++) {
                    if (j == 0) {
                        strGrafica += ("F"+Integer.toString(i) + "; ");
                    }
                    else{
                        strGrafica += ((Integer.toString(i))+(Integer.toString(j-1)) + "; ");
                    }
                }
                strGrafica += "} \n";
            }
        }
        
        strGrafica += "}";
        
        ruta = "graficaHash.dot";
        archivoGrafica = new File(ruta);
        BufferedWriter bw;
        try {
            bw = new BufferedWriter(new FileWriter(archivoGrafica));
            bw.write(strGrafica);
            bw.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            String cmd1 = "dot -Tpng graficaHash.dot -o graficaHash.png"; //Comando de apagado en linux
            Runtime.getRuntime().exec(cmd1);
            //String cmd2 = "display graficaLCD.png &";
            //Runtime.getRuntime().exec(cmd2);
        } catch (IOException ioe) {
                System.out.println (ioe);
        }
    }
    
    protected void iniciarGrafica(){
        try {
            Desktop desk;
            desk = Desktop.getDesktop();
            //desk.open(archivoGrafica);
            desk.open(new File("graficaHash.png"));
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
