package proyecto2edd;

public class Conductor {
    public String dpi;
    public String nombre;
    public String apellido;
    public String licencia;
    public String genero;
    public String fechaNac;
    public String telefono;
    public String direccion;
    
    public Conductor(String dpi, String nombre, String apellido, String licencia, String genero, String fechaNac, String telefono, String direccion){
        this.dpi = dpi;
        this.nombre = nombre;
        this.apellido = apellido;
        this.licencia = licencia;
        this.genero = genero;
        this.fechaNac = fechaNac;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    public String getDpi() {
        return dpi;
    }

    public void setDpi(String dpi) {
        this.dpi = dpi;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    
    public String getLicencia(){
        return licencia;
    }
    
    public void setLicencia(String licencia){
        this.licencia = licencia;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    public String getFechaNac(){
        return fechaNac;
    }
    
    public void setFechaNac(){
        this.fechaNac = fechaNac;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
