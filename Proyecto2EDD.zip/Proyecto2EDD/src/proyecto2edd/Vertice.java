package proyecto2edd;

public class Vertice {
    String nombre;
    int numVertice;
    
    public Vertice(String nombre){
        this.nombre = nombre;
        numVertice = -1;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    
    public boolean igual(Vertice x){ //TRUE, SI DOS VERTICES SON IGUALES
        return nombre.equals(x.getNombre());
    }
    
    public void setNumVertice(int n){ //ESTABLECE EL NUMERO DE VERTICES
        this.numVertice = n;
    }
    
    @Override
    public String toString(){
        return nombre + " (" + numVertice + ")";
    }
}
