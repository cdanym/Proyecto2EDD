package proyecto2edd;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Grafo {
    
    int numVertices;
    static int MaxVertices;
    Vertice[] vertices;
    int[][] matrizAdy;
    
    File archivoGrafica, grafica;
    String ruta;
    String strGrafica;
    
    public Grafo(int mx){
        MaxVertices =  mx;
        matrizAdy = new int[mx][mx];
        vertices = new Vertice[mx];
        for (int i = 0; i < mx; i++) {
            for (int j = 0; j < mx; j++) {
                matrizAdy[i][j] = 0;
            }
        }
        numVertices = 0;
    }
    
    public void nuevoVertice(String nom){
        boolean esta = numVertice(nom) >= 0;
        if (!esta) {
            Vertice v = new Vertice(nom);
            v.setNumVertice(numVertices);
            vertices[numVertices++] = v;
        }        
    }
    
    public int numVertice(String vert){ //BUSCA EL VERTICE EN EL ARRAY, DEVUELVE -1 SI NO LO ENCUENTRA
        Vertice v = new Vertice(vert);
        boolean encontrado = false;
        int i = 0;
        for (; (i < numVertices) && !encontrado ;) {
            encontrado = vertices[i].equals(v);
            if (!encontrado){
                i++;
            }
        }
        System.out.println("Met numVertice: " + i);
        return (i<numVertices) ? i : -1;
    }
    
    public int buscarVertice(String vert){
        int i = 0;
        for (int j = 0; j < MaxVertices; j++) {
            if(vertices[j].nombre.equals(vert)){
                i = j;
                return i;
            }
        }
        return i;
    }
    
    public void nuevoArco(String a, String b, int peso)throws Exception{
        int va, vb;
        //va = numVertice(a);
        //vb = numVertice(b);
        va = buscarVertice(a);
        vb = buscarVertice(b);
        System.out.println("va:" + va + " vb:"+vb);
        //if (va < 0 || vb < 0); //throw new Exception("Vertice no existe");
        matrizAdy[va][vb] = peso;
    }
    
    public boolean adyacente(String a, String b) throws Exception{
        int va, vb;
        va = numVertice(a);
        vb = numVertice(b);
        if (va < 0 || vb < 0); //throw new Exception ("Vértice no existe");
	return matrizAdy[va][vb] == 1;
    }
    
    public void imprimirMatriz(){
        for (int i = 0; i < MaxVertices; i++) {
            for (int j = 0; j < MaxVertices; j++) {
                System.out.print(" " + matrizAdy[i][j] + " ");
            }
            System.out.println("");
        }
        crearGrafica();
        iniciarGrafica();
    }
    
    protected void crearGrafica(){
        strGrafica = "digraph g { ";
        String nodo = "";
        
        for (int i = 0; i < MaxVertices; i++) {
            for (int j = 0; j < MaxVertices; j++) {
                if (matrizAdy[i][j]!=0) {
                    strGrafica += (vertices[i].getNombre() + " -> " + vertices[j].getNombre() + "[label=\"" + matrizAdy[i][j] + "\"]; \n");
                }
            }
        }
        
        strGrafica += "}";
        //ruta="C:\\Users\\Daniel\\Desktop\\TablaTokens.html";
        ruta = "graficaGrafo.dot";
        archivoGrafica = new File(ruta);
        BufferedWriter bw;
        try {
            bw = new BufferedWriter(new FileWriter(archivoGrafica));
            bw.write(strGrafica);
            bw.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            String cmd1 = "dot -Tpng graficaGrafo.dot -o graficaGrafo.png"; //Comando de apagado en linux
            Runtime.getRuntime().exec(cmd1);
            //String cmd2 = "display graficaLCD.png &";
            //Runtime.getRuntime().exec(cmd2);
        } catch (IOException ioe) {
                System.out.println (ioe);
        }
    }
    
    protected void iniciarGrafica(){
        try {
            Desktop desk;
            desk = Desktop.getDesktop();
            //desk.open(archivoGrafica);
            desk.open(new File("graficaGrafo.png"));
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
